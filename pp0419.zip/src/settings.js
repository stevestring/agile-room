var settings =
    {
        "serverurl": "http://planning-poker-server.us-east-1.elasticbeanstalk.com",
        "serverurl-local": "http://localhost:3000"
    }

module.exports =   settings;